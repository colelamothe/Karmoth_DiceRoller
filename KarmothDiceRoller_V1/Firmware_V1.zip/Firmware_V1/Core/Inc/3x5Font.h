/*
 * 3x5Font.h
 *
 *  Created on: Aug 17, 2024
 *      Author: Mothm
 */

#ifndef INC_3X5FONT_H_
#define INC_3X5FONT_H_



#endif /* INC_3X5FONT_H_ */

extern int zero[5][3];
extern int one[5][3];
extern int two[5][3];
extern int three[5][3];
extern int four[5][3];
extern int five[5][3];
extern int six[5][3];
extern int seven[5][3];
extern int eight[5][3];
extern int nine[5][3];
