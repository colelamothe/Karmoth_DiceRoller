/*
 * matrixLED.h
 *
 *  Created on: Aug 17, 2024
 *      Author: Mothm
 */

#ifndef INC_MATRIXLED_H_
#define INC_MATRIXLED_H_

void updateNumber(int inputNumber);
void refreshDisplay();
void scrollDisplay();

#endif /* INC_MATRIXLED_H_ */
